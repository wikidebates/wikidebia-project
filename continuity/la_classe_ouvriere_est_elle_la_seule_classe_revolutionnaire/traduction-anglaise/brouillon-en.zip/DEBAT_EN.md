# Is the working class the only revolutionary class?

Working class · Debate under construction


## Arguments for

- [The working class is the only social force capable of overthrowing capitalism](pages/arguments/A0001.wiki)
- [The working class is the only class that can bring about a new economic order free from exploitation](pages/arguments/A0002.wiki)
- [The working class is the only class capable of uniting and organising for revolution](pages/arguments/A0003.wiki)
- [The working class is the only class capable of seeing the revolutionary struggle through to the end](pages/arguments/A0004.wiki)
- [The working class has demonstrated its ability to carry out a revolution](pages/arguments/A0005.wiki)
- [The other classes are not revolutionary](pages/arguments/A0006.wiki)

## Arguments against

- [The working class does not exist](pages/arguments/A0007.wiki)
- [The concept of the working class is problematic](pages/arguments/A0008.wiki)
- [The working class is too integrated into bourgeois society](pages/arguments/A0009.wiki)
- [The working class has lost its economic power](pages/arguments/A0010.wiki)
- [Working-class organisations have lost their base and legitimacy](pages/arguments/A0011.wiki)
- [The working class has lost its militancy](pages/arguments/A0012.wiki)
- [The working class is too divided to be conscious of itself as a class](pages/arguments/A0013.wiki)
- [A revolution can and must take place without the working class](pages/arguments/A0014.wiki)
- [We must give up the fantasy of revolution](pages/arguments/A0015.wiki)

## Reading

- Karl Marx and Friedrich Engels, *The Communist Manifesto*. [Project Gutenberg](https://www.gutenberg.org/ebooks/61)
- Theda Skocpol, *States and Social Revolutions: A Comparative Analysis of France, Russia and China*. [Cambridge University Press](https://www.cambridge.org/core/books/states-and-social-revolutions/9481262B2BDA1BFFB3C9218DBD447190)
- [Working class](https://en.wikipedia.org/wiki/Working_class)

[French source](https://fr.wikidebates.org/wiki/Special:PermanentLink/267940) · [Draft wikicode](pages/debate/Debate.wiki)

[All arguments by title](INDEX_EN.md)
