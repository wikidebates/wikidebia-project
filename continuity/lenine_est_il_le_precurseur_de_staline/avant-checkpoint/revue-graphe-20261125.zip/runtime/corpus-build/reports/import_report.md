# Initialisation du corpus — Lénine est-il le précurseur de Staline ?

Statut : `graph_draft`.

- Nœuds : 1144
- Relations : 1244
- Occurrences normatives : 1261
- Pages sources importées : 1145
- Normalisations ou replis consignés : 293

Les fichiers `imports/fr/` ne sont pas des pages de sortie validées.
