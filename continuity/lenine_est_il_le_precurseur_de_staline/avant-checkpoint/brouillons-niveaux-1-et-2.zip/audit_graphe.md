# Audit du graphe — « Lénine est-il le précurseur de Staline ? »

**Résultat : RÉUSSI**

| Contrôle | Résultat | Détail |
|---|---:|---|
| racines uniques | OK | 17 |
| débat déjà traduit sans parcours argumentatif | OK |  |
| racines présentes | OK |  |
| nœuds uniques | OK | 1144 |
| relations uniques | OK | 1244 |
| provenance des pages manquantes | OK | [] |
| types de relation | OK |  |
| endpoints présents | OK | [] |
| graphe sans cycle | OK | [] |
| frontières sans sorties | OK | [] |
| frontières de profondeur sans sorties | OK | [] |
| frontières de traduction anglaise sans sorties | OK | [] |
| compteur nœuds | OK | 1144/1144 |
| compteur relations | OK | 1244/1244 |
| compteurs justification/objection | OK |  |
| compteur des arguments par niveau | OK | {1: 17, 2: 146, 3: 318, 4: 283, 5: 191, 6: 106, 7: 47, 8: 26, 9: 9, 10: 1} |
| somme des pages par niveau minimal | OK | 1144/1144 |
| somme des occurrences dépliées par niveau | OK | 2117/2117 |
| cohérence niveau maximal et profondeur en arêtes | OK | niveau=13; profondeur=12 |
| niveau minimal maximal inférieur ou égal au niveau maximal des occurrences | OK | (10, 13) |
| compteur des pages sans sortie | OK | 662 |
| compteur des feuilles réelles | OK | 658 |
| relations locales ignorées aux frontières | OK | 0 |
| traductions anglaises existantes | OK | {'Aucun exemple historique ne montre des droits acquis sans que personne ait usé de violence': 'No rights have ever been won historically without someone using violence', 'Le mandat de Hollande a été marqué par des idéologies sécuritaires et racistes': "Hollande's presidency was marked by security-driven and racist ideologies", 'Le pouvoir politique est entre les mains des grandes entreprises et de la finance': 'Political power is in the hands of big business and finance', 'Les nazis eux-mêmes faisaient de la démagogie sociale': 'Even the Nazis used social demagoguery'} |
| compteur des arguments à traduire | OK | 1140 |
| relations ignorées aux traductions anglaises existantes | OK | 7 |
| relations ignorées à la limite de profondeur | OK | 0 |
| aucune page manquante | OK | [] |
| snapshot complet | OK | {'argument_pages': 1144, 'debate_pages': 1, 'total_pages': 1145} |
| empreintes du snapshot | OK | 1145 |
