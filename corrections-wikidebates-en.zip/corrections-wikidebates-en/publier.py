#!/usr/bin/env python3
"""Appliquer le lot anglais à des révisions existantes avec les adaptateurs Wikidéb’IA."""
import argparse
import fcntl
import json
from pathlib import Path
import re
import sys

BUNDLE = Path(__file__).resolve().parent
SITE = 'en.wikidebates.org'
ALLOWED_FIELDS = {'keywords', 'sections', 'quotes', 'pro-bibliography', 'con-bibliography', 'bibliography'}


def load_lot():
    from wikidebia_fr_publication_relay import digest, request_hash, safe_file
    from wikidebia_update import (
        assert_citation_change_authorized, assert_relation_rendering_safe,
        assert_summary_change_authorized, changed_top_level_parameters, content_diff_edit_summary,
    )
    from wikidebia_validator.wikicode import parse_template

    lot = json.loads(safe_file(BUNDLE, 'lot.json').read_text(encoding='utf-8'))
    if (lot.get('schema') != 'corrections-wikidebates-en-1.0'
            or lot.get('site') != 'https://' + SITE or lot.get('language') != 'en'
            or lot.get('request_sha256') != request_hash(lot)):
        raise ValueError('Identité ou empreinte du lot invalide.')
    rows = lot['pages']
    if len(rows) != 19:
        raise ValueError('Le lot doit couvrir 19 pages.')
    for key in ('title', 'page_id', 'source_revision_id'):
        if len({r[key] for r in rows}) != len(rows):
            raise ValueError(f'Doublon dans {key}.')
    quotes = 0
    for row in rows:
        title, page_id, revision = row['title'], row['page_id'], row['source_revision_id']
        if (type(page_id) is not int or page_id <= 0 or type(revision) is not int or revision <= 0
                or not isinstance(title, str) or not title.strip() or re.search(r'[\x00-\x1f\x7f\[\]{}<>|#]', title)):
            raise ValueError('Identité de page invalide.')
        before = safe_file(BUNDLE, row['before']).read_bytes()
        after = safe_file(BUNDLE, row['after']).read_bytes()
        if digest(before) != row['source_sha256'] or digest(after) != row['target_sha256'] or before == after:
            raise ValueError(f'Empreintes divergentes pour {title}.')
        original, target = before.decode('utf-8'), after.decode('utf-8')
        before_template, after_template = parse_template(original), parse_template(target)
        expected_model = 'Debate' if page_id == 6590 else 'Argument'
        if before_template.name != expected_model or after_template.name != expected_model:
            raise ValueError(f'Modèle inattendu pour {title}.')
        kind = expected_model.lower()
        fields = changed_top_level_parameters(original, target, 'en', kind)
        if fields != row['changed_parameters'] or not set(fields) <= ALLOWED_FIELDS:
            raise ValueError(f'Champs inattendus pour {title}.')
        if 'quotes' in fields:
            old = before_template.one('quotes') or ''
            new = after_template.one('quotes') or ''
            expected, count = re.subn(r'(?m)^\|authors=Marylène Pathou-Mathis$', '|authors=Marylène Patou-Mathis', old)
            if not count or expected != new:
                raise ValueError(f'Delta de citation inattendu pour {title}.')
            quotes += count
        assert_summary_change_authorized(original, target, 'en', kind)
        assert_citation_change_authorized(original, target, row.get('citation_change_authorization'))
        assert_relation_rendering_safe(original, target, 'en', kind)
        if content_diff_edit_summary(original, target, 'en', kind) != row['edit_summary']:
            raise ValueError(f'Commentaire d’édition divergent pour {title}.')
        row['target_text'] = target
        row['new_title'] = title
    if quotes != 20:
        raise ValueError('Le lot doit corriger exactement 20 attributions.')
    return lot


def checked_states(adapter, rows, user):
    from wikidebia_fr_publication_relay import digest, target_content_matches, verify_update

    states = []
    snapshot = adapter.read_pages([r['title'] for r in rows])
    for row in rows:
        title, base = row['title'], row['source_revision_id']
        exists, revision, text = snapshot[title]
        if not exists or not revision:
            raise ValueError(f'Page absente : {title}.')
        evidence = adapter.read_revision(title, revision)
        if (not evidence or not evidence.get('revision_identity_complete')
                or evidence['page_id'] != row['page_id'] or evidence['title'] != title
                or evidence['text'] != text):
            raise ValueError(f'Identité ou révision distante non confirmée : {title}.')
        if revision == base and digest(text.encode('utf-8')) == row['source_sha256']:
            states.append(None)
        elif target_content_matches(text, row):
            verify_update(adapter, row, revision, base, user, row['edit_summary'])
            states.append(revision)
        else:
            raise ValueError(f'Révision divergente pour {title} (base {base}, actuelle {revision}).')
    return states


def operate(adapter, lot, user, execute):
    from wikidebia_fr_publication_relay import verify_update

    adapter.assert_identity(user)
    if 'edit' not in adapter.user_rights() or 'chatgpt' not in adapter.available_change_tags():
        raise ValueError('Droit edit ou balise chatgpt indisponible pour le compte configuré.')
    rows = lot['pages']
    states = checked_states(adapter, rows, user)
    for row, revision in zip(rows, states, strict=True):
        description = f'vérifiée en révision {revision}' if revision else f'base {row["source_revision_id"]} conforme'
        print(f'{row["title"]} — {description}', flush=True)
    if not execute:
        return states
    for row, revision in zip(rows, states, strict=True):
        if revision is not None:
            continue
        current, = checked_states(adapter, [row], user)
        if current is not None:
            continue
        title, base = row['title'], row['source_revision_id']
        revision = adapter.write_page(title=title, text=row['target_text'], summary=row['edit_summary'],
                                      tags=['chatgpt'], expected_user=user, create_only=False,
                                      base_revision_id=base)
        verify_update(adapter, row, revision, base, user, row['edit_summary'])
        print(f'Publié et vérifié — {title} · {revision}', flush=True)
    final = checked_states(adapter, rows, user)
    if None in final:
        raise ValueError('Certaines cibles ne sont pas publiées.')
    return final


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--depot', required=True, type=Path, help='Checkout Wikidéb’IA du serveur')
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--verifier-archive', action='store_true')
    mode.add_argument('--preflight', action='store_true')
    mode.add_argument('--publier', action='store_true')
    parser.add_argument('--confirmer-sha256')
    args = parser.parse_args()
    root = args.depot.resolve()
    for path in ('kit/scripts/wikidebia_update.py', 'validator/src/wikidebia_validator/wikicode.py'):
        if not (root / path).is_file():
            raise ValueError('Checkout Wikidéb’IA incomplet.')
    sys.path[:0] = [str(root / 'kit/scripts'), str(root / 'validator/src')]
    lot = load_lot()
    signature = lot['request_sha256']
    if args.confirmer_sha256 and not args.publier:
        parser.error('--confirmer-sha256 est réservé à --publier')
    if args.publier and args.confirmer_sha256 != signature:
        parser.error('--publier exige l’empreinte SHA-256 affichée par le préflight')
    print(f'Empreinte SHA-256 du lot {signature}', flush=True)
    if args.verifier_archive:
        print('19 pages et 20 attributions vérifiées localement.')
        return

    from wikidebia_manage import load_local_settings
    from wikidebia_update import build_adapter

    settings = load_local_settings(root)
    user = (settings.get('expected_users') or {}).get('en')
    if not isinstance(user, str) or not user.strip():
        raise ValueError('Compte de publication anglais attendu absent de la configuration.')
    config = {'family': settings.get('family') or 'wikidebates', 'languages': ['en'],
              'sites': {'en': {'code': 'en'}}, 'pywikibot_dir': 'private/pywikibot',
              'family_file': 'kit/families/wikidebates_family.py'}
    adapter = build_adapter(config, root)
    # Two invocations from the same unpacked bundle must not write in parallel.
    with (BUNDLE / '.publication.lock').open('a', encoding='utf-8') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            adapter.open_language('en', user)
            if adapter.site.hostname() != SITE:
                raise ValueError('Le site configuré ne correspond pas au wiki anglais.')
            states = operate(adapter, lot, user, args.publier)
            if None in states:
                print(f'Préflight réussi. {states.count(None)} page(s) à publier.')
            else:
                print('Publication vérifiée pour les 19 pages.')
        finally:
            adapter.close_language()


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # Auth and HTTP exceptions may contain request details. Only show errors
        # that describe this bundle's own checks or the relay's revision checks.
        if isinstance(error, ValueError) or type(error).__name__ == 'Blocked':
            print(f'Opération arrêtée. {error}', file=sys.stderr)
        else:
            print(f'Opération arrêtée. {type(error).__name__}. Relancez le préflight avant toute reprise.', file=sys.stderr)
        raise SystemExit(2)
