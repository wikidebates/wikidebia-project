# Corrections anglaises du débat « Has violence always existed? »

Ce lot cible 19 pages existantes sur `en.wikidebates.org`. Il comprend les modifications des rubriques et des mots-clés, trois références bibliographiques et la rectification de 20 attributions en « Marylène Patou-Mathis ». Les fichiers `before/` et `after/` contiennent les wikicodes complets. `lot.json` indique la révision de départ, les champs concernés, le commentaire d’édition et les empreintes de chaque page.

Le script `publier.py` réutilise les adaptateurs Wikidéb’IA installés sur le serveur. Il s’agit d’un lot ponctuel de corrections et d’un contrôle de ses révisions. Le parcours de reprise d’un corpus complet passe par `./wikidebia update`.

## Sur le serveur Debian

Décompressez l’archive dans un dossier accessible au compte qui exécute Wikidéb’IA. Lancez les commandes suivantes depuis le dépôt Wikidéb’IA avec l’environnement Python du kit. Le lot a été préparé sur le commit `61ab39af4607f832fa06c2d5d9eeb5936a86cbfe`, avec le kit 2.16.49 et le validateur 0.4.107.

```bash
# Remplacez ce chemin par celui où vous avez extrait l’archive.
SCRIPT=/chemin/vers/corrections-wikidebates-en/publier.py
.venv/bin/python "$SCRIPT" --depot "$PWD" --verifier-archive
.venv/bin/python "$SCRIPT" --depot "$PWD" --preflight
```

Le préflight utilise les identifiants anglais déjà configurés sur le serveur, avec la configuration locale Pywikibot ou les secrets gérés par Wikidéb’IA. Le compte attendu est celui de `expected_users.en` s’il est configuré, ou `ChatGPT` par défaut. Il vérifie le compte attendu, le droit d’édition, la balise `chatgpt`, l’identité et l’empreinte des 19 pages. Il ne publie aucune modification.

Examinez le diff dans `modifications.diff`. Si le préflight réussit, utilisez l’empreinte qu’il affiche.

```bash
.venv/bin/python "$SCRIPT" --depot "$PWD" --publier \
  --confirmer-sha256 EMPREINTE_AFFICHEE_PAR_LE_PREFLIGHT
```

L’exécution refait le préflight. Chaque édition vise sa révision de départ et est relue pour confirmer son contenu, son auteur, sa révision parente, son commentaire et sa balise. Le script s’arrête en cas de divergence. Si une exécution s’interrompt après quelques éditions, relancez le préflight. Il reconnaît celles qui correspondent exactement au lot et à l’historique attendu. Relancez ensuite la même commande de publication avec la même empreinte. En cas de modification tierce, examinez la révision divergente avant de poursuivre.

Aucun identifiant n’est fourni dans ce lot. Le script ne crée, ne déplace et ne supprime aucune page. Le test local et la validation différentielle n’utilisent pas le compte de production. Le préflight sur le serveur vérifie cet accès.

## Vérification locale

Le validateur Wikidéb’IA 0.4.107 a comparé 46 wikicodes français et anglais, avant et après corrections, avec les portées `wikicode` et `bilingual`. Les quatre avertissements de correspondance des rubriques `WDV-BIL-004` disparaissent. Le contrôle ne signale aucun diagnostic nouveau. La vérification vise le contenu du lot ponctuel et ne vaut pas validation d’un corpus complet.
